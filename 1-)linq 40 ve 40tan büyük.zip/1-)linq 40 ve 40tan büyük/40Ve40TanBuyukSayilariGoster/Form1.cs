﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _40Ve40TanBuyukSayilariGoster
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ShowItemButtonClickListener(object sender, EventArgs e) // ShowItems butonuna tıklandığında çalışacak olan fonksiyon
        {
            int[] array = { 25, 10, 40, 60, 80 }; // İçinden ayrıştırma yapıkacal olan dizi.

            IEnumerable<int> items = array.Where(n => n >= 40); // LINQ sorgusu ile 40'a eşit yada 40'tan büyük öğeler items adlı enumarable objeye gönderilir.

            itemListBox.DataSource = items.ToList(); // Enumerable obje liste veri tipine çevirilir ve itemListBox ta gösterlilir.
        }
    }
}
